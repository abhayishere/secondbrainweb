chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "user-loggedin") {
        console.log("TOKEN IS RECEIVED IN BACKGROUND");
        chrome.storage.local.set({ authToken: message.token }, () => {
            console.log("Token stored successfully.");
        });
    }

    if (message.action === "logOut") {
        console.log("LOGOUT IS RECEIVED IN BACKGROUND");
        chrome.storage.local.clear(() => {
            console.log("Token cleared successfully.");
        });
    }
});
