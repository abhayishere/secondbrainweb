// Helper function
function isChromeRuntimeAvailable() {
    return typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id;
}

// Initialize UI and attach event listeners
function initializeUI() {
    // Create floating button
    const floatingButton = document.createElement("button");
    floatingButton.id = "floating-btn";
    floatingButton.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48" fill="none">
        <circle cx="24" cy="24" r="24" fill="white" />
        <svg xmlns="http://www.w3.org/2000/svg" x="8" y="8" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icon-tabler-brain">
            <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
            <path d="M15.5 13a3.5 3.5 0 0 0 -3.5 3.5v1a3.5 3.5 0 0 0 7 0v-1.8" />
            <path d="M8.5 13a3.5 3.5 0 0 1 3.5 3.5v1a3.5 3.5 0 0 1 -7 0v-1.8" />
            <path d="M17.5 16a3.5 3.5 0 0 0 0 -7h-.5" />
            <path d="M19 9.3v-2.8a3.5 3.5 0 0 0 -7 0" />
            <path d="M6.5 16a3.5 3.5 0 0 1 0 -7h.5" />
            <path d="M5 9.3v-2.8a3.5 3.5 0 0 1 7 0v10" />
        </svg>
    </svg>`;

    // Create login popup
    const loginPopup = document.createElement("div");
    loginPopup.id = "login-popup";
    loginPopup.innerHTML = `
        <div id="login-content">
            <h3 id="popup-title">Welcome to SecondBrain</h3>
            <button id="login-btn">Login</button>
        </div>
    `;

    // Create description popup
    const descriptionPopup = document.createElement("div");
    descriptionPopup.id = "popup";
    descriptionPopup.innerHTML = `
        <div id="popup-content">
            <div id="popup-header">
                <h3 id="popup-title">Add Description</h3>
                <button id="logout-btn">Logout</button>
            </div>
            <input 
                type="text" 
                id="title-input" 
                placeholder="Enter title..."
            />
            <textarea 
                id="context-input" 
                placeholder="Start noodling..." 
                rows="4"
            ></textarea>
            <button id="save-btn">Save</button>
        </div>
    `;

    // Add elements to DOM
    document.body.appendChild(floatingButton);
    document.body.appendChild(loginPopup);
    document.body.appendChild(descriptionPopup);

    // Add styles
    const style = document.createElement("style");
    style.textContent = `
        #floating-btn {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: none;
            border: none;
            border-radius: 50%;
            width: 64px;
            height: 64px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            z-index: 1000;
            padding: 0;
            transition: transform 0.2s;
        }
        #floating-btn:hover {
            transform: scale(1.1);
        }
        #floating-btn svg {
            width: 48px;
            height: 48px;
        }
        
        #login-popup, #popup {
            position: fixed;
            bottom: 90px;
            right: 20px;
            width: 300px;
            background: linear-gradient(145deg, #ffffff 0%, #f5f5f5 100%);
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            display: none;
            text-align: center;
        }

        #popup-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        #popup-title {
            font-size: 18px;
            font-weight: 700;
            color: #2c2c2c;
            margin: 0;
        }

        #logout-btn {
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            background: linear-gradient(145deg, #f0f0f0 0%, #e0e0e0 100%);
            color: #333;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.2s ease;
        }

        #logout-btn:hover {
            background: #ff4444;
            color: white;
            transform: translateY(-2px);
        }

        #login-btn {
            padding: 12px 24px;
            width: 80%;
            border: none;
            border-radius: 8px;
            background: linear-gradient(145deg, #2c2c2c 0%, #1a1a1a 100%);
            color: white;
            cursor: pointer;
            font-weight: 600;
            font-size: 15px;
            transition: transform 0.2s ease, opacity 0.2s ease;
            margin-top: 10px;
        }

        #login-btn:hover {
            transform: translateY(-2px);
            opacity: 0.9;
        }

        #context-input {
            width: 100%;
            padding: 12px;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            resize: none;
            font-family: Arial, sans-serif;
            font-size: 14px;
            background: #ffffff;
            margin-bottom: 15px;
        }

        #save-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            background: linear-gradient(145deg, #2c2c2c 0%, #1a1a1a 100%);
            color: white;
            cursor: pointer;
            font-weight: 600;
            transition: transform 0.2s ease, opacity 0.2s ease;
        }

        #save-btn:hover {
            transform: translateY(-2px);
            opacity: 0.9;
        }

        #title-input {
            width: 100%;
            padding: 12px;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            font-family: Arial, sans-serif;
            font-size: 14px;
            background: #ffffff;
            margin-bottom: 10px;
        }

        #title-input:focus {
            outline: none;
            border-color: #666;
        }
    `;
    document.head.appendChild(style);

    // Initialize event listeners
    floatingButton.addEventListener('click', (event) => {
        event.stopPropagation();
        checkAuthAndShowPopup();
    });

    const loginBtn = document.getElementById('login-btn');
    if (loginBtn) {
        loginBtn.addEventListener('click', () => {
            if (!isChromeRuntimeAvailable()) {
                window.location.reload();
                return;
            }
            window.open('https://secondbrainweb.vercel.app/', '_blank');
        });
    }

    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            if (!isChromeRuntimeAvailable()) {
                window.location.reload();
                return;
            }
            chrome.storage.local.remove('authToken', () => {
                const loginPopup = document.getElementById('login-popup');
                const descriptionPopup = document.getElementById('popup');
                loginPopup.style.display = 'block';
                descriptionPopup.style.display = 'none';
            });
        });
    }

    const saveBtn = document.getElementById('save-btn');
    if (saveBtn) {
        saveBtn.addEventListener('click', async () => {
            if (!isChromeRuntimeAvailable()) {
                window.location.reload();
                return;
            }

            const title = document.getElementById('title-input').value;
            const description = document.getElementById('context-input').value;
            const currentUrl = window.location.href; // Get URL directly from window

            // Validate inputs
            if (!title.trim() || !description.trim()) {
                alert('Please fill in both title and description');
                return;
            }

            try {
                chrome.storage.local.get('authToken', async (data) => {
                    if (data.authToken) {
                        const response = await fetch('https://secondbrainbe.onrender.com/api/savelink', {
                            method: 'POST',
                            headers: {
                                'Authorization': `Bearer ${data.authToken}`,
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                url: currentUrl,
                                title: title,
                                description: description
                            })
                        });

                        if (response.ok) {
                            // Clear inputs and hide popup on success
                            document.getElementById('title-input').value = '';
                            document.getElementById('context-input').value = '';
                            document.getElementById('popup').style.display = 'none';
                            alert('Saved successfully!');
                        } else {
                            const errorData = await response.json();
                            alert(`Failed to save: ${errorData.message || 'Unknown error'}`);
                        }
                    } else {
                        alert('Please login first');
                        document.getElementById('popup').style.display = 'none';
                        document.getElementById('login-popup').style.display = 'block';
                    }
                });
            } catch (error) {
                console.error('Error saving data:', error);
                alert('Failed to save. Please try again.');
            }
        });
    }

    // Close popups when clicking outside
    document.addEventListener('click', (event) => {
        const loginPopup = document.getElementById('login-popup');
        const descriptionPopup = document.getElementById('popup');
        const floatingBtn = document.getElementById('floating-btn');
        
        if (!floatingBtn.contains(event.target) && 
            !loginPopup.contains(event.target) && 
            !descriptionPopup.contains(event.target)) {
            loginPopup.style.display = 'none';
            descriptionPopup.style.display = 'none';
        }
    });
}

// Check auth state and show appropriate popup
function checkAuthAndShowPopup() {
    if (!isChromeRuntimeAvailable()) {
        console.log('Chrome runtime not available, reloading page...');
        window.location.reload();
        return;
    }

    try {
        chrome.storage.local.get('authToken', (data) => {
            const loginPopup = document.getElementById('login-popup');
            const descriptionPopup = document.getElementById('popup');
            
            if (data.authToken) {
                loginPopup.style.display = 'none';
                descriptionPopup.style.display = 'block';
            } else {
                loginPopup.style.display = 'block';
                descriptionPopup.style.display = 'none';
            }
        });
    } catch (error) {
        console.log('Error checking auth state:', error);
        window.location.reload();
    }
}

// Add message listeners
function addMessageListeners() {
    if (!isChromeRuntimeAvailable()) return;

    window.addEventListener("message", (event) => {
        if (event.data.action === "storeToken") {
            try {
                console.log("event data", event.data);
                const token = event.data.message;
                console.log("token ", token);
                chrome.runtime.sendMessage({ action: "user-loggedin", token: token });
            } catch (error) {
                console.log('Error in storeToken handler:', error);
            }
        }
    });

    window.addEventListener("message", (event) => {
        if (event.data.action === "logOut") {
            try {
                const token = event.data.message;
                console.log("logout ", token);
                chrome.runtime.sendMessage({ action: "logOut", token: token });
            } catch (error) {
                console.log('Error in logout handler:', error);
            }
        }
    });
}

// Initialize everything
initializeUI();
addMessageListeners();